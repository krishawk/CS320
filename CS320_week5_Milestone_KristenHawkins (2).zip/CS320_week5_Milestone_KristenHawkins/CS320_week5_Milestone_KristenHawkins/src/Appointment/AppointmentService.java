
package Appointment;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class AppointmentService {
  final private List<Appointment> appointList = new ArrayList<>();

  private String newUniqueId() {
    return UUID.randomUUID().toString().substring(
        0, Math.min(toString().length(), 10));
  }

  public void newAppointment() {
    Appointment appt = new Appointment(newUniqueId());
    appointList.add(appt);
  }

  public void newAppointment(Date date) {
    Appointment appt = new Appointment(newUniqueId(), date);
    appointList.add(appt);
  }

  public void newAppointment(Date date, String description) {
    Appointment appt = new Appointment(newUniqueId(), date, description);
    appointList.add(appt);
  }

  public void deleteAppointment(String id) throws Exception {
    appointList.remove(searchForAppointment(id));
  }

  protected List<Appointment> getAppointmentList() { return appointList; }

  private Appointment searchForAppointment(String id) throws Exception {
    int index = 0;
    while (index < appointList.size()) {
      if (id.equals(appointList.get(index).getAppointmentId())) {
        return appointList.get(index);
      }
      index++;
    }
    throw new Exception("This appointment does not exist!");
  }
}