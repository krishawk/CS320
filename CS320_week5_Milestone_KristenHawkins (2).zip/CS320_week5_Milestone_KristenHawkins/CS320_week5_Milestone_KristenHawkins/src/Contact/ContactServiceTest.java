package Contact;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ContactServiceTest {
	protected String contactID, firstName, lastName, number, address, longContactID, longFirstName, longLastName,
			longNumber, longAddress, shortNumber;

	@BeforeEach
	void setUp() {
		contactID = "659856985";
		address = "INITIAL";
		lastName = "INITIAL";
		number = "9876543210";
		address = "INITIAL";
		longContactID = "012345678901";
		longFirstName = "hdgfhrtdgfhdyehdgdtrhr";
		longLastName = "jfhdhdhyehennendhdhd";
		longNumber = "5264599856522";
		longAddress = "1600 really long address for test Av springfield";
		shortNumber = "2";
	}

	@Test
	void newContactTest() {
		ContactService service = new ContactService();

		service.newContact();
		assertAll("service", () -> assertNotNull(service.getContactList().get(0).getContactID()),
				() -> assertEquals("INITIAL", service.getContactList().get(0).getFirstName()),
				() -> assertEquals("INITIAL", service.getContactList().get(0).getLastName()),
				() -> assertEquals("9876543210", service.getContactList().get(0).getNumber()),
				() -> assertEquals("INITIAL", service.getContactList().get(0).getAddress()));

		service.newContact(address);
		assertAll("service", () -> assertNotNull(service.getContactList().get(1).getContactID()),
				() -> assertEquals(address, service.getContactList().get(1).getFirstName()),
				() -> assertEquals("INITIAL", service.getContactList().get(1).getLastName()),
				() -> assertEquals("9876543210", service.getContactList().get(1).getNumber()),
				() -> assertEquals("INITIAL", service.getContactList().get(1).getAddress()));

		service.newContact(address, lastName);
		assertAll("service", () -> assertNotNull(service.getContactList().get(2).getContactID()),
				() -> assertEquals(address, service.getContactList().get(2).getFirstName()),
				() -> assertEquals(lastName, service.getContactList().get(2).getLastName()),
				() -> assertEquals("9876543210", service.getContactList().get(2).getNumber()),
				() -> assertEquals("INITIAL", service.getContactList().get(2).getAddress()));

		service.newContact(address, lastName, number);
		assertAll("service", () -> assertNotNull(service.getContactList().get(3).getContactID()),
				() -> assertEquals(address, service.getContactList().get(3).getFirstName()),
				() -> assertEquals(lastName, service.getContactList().get(3).getLastName()),
				() -> assertEquals(number, service.getContactList().get(3).getNumber()),
				() -> assertEquals("INITIAL", service.getContactList().get(3).getAddress()));

		service.newContact(address, lastName, number, address);
		assertAll("service", () -> assertNotNull(service.getContactList().get(4).getContactID()),
				() -> assertEquals(address, service.getContactList().get(4).getFirstName()),
				() -> assertEquals(lastName, service.getContactList().get(4).getLastName()),
				() -> assertEquals(number, service.getContactList().get(4).getNumber()),
				() -> assertEquals(address, service.getContactList().get(4).getAddress()));

	}

	@Test
	void deleteContactTest() {
		ContactService service = new ContactService();
		service.newContact();
		assertThrows(Exception.class, () -> service.deleteContact(contactID));
		assertAll(() -> service.deleteContact(service.getContactList().get(0).getContactID()));
	}

	@Test
	void updateFirstNameTest() throws Exception {
		ContactService service = new ContactService();
		service.newContact();
		service.setFirstName(service.getContactList().get(0).getContactID(), address);
		assertEquals(address, service.getContactList().get(0).getFirstName());
		assertThrows(IllegalArgumentException.class,
				() -> service.setFirstName(service.getContactList().get(0).getContactID(), longFirstName));
		assertThrows(IllegalArgumentException.class,
				() -> service.setFirstName(service.getContactList().get(0).getContactID(), null));
		assertThrows(Exception.class, () -> service.setFirstName(contactID, address));
	}

	@Test
	void updateLastNameTest() throws Exception {
		ContactService service = new ContactService();
		service.newContact();
		service.setLastName(service.getContactList().get(0).getContactID(), lastName);
		assertEquals(lastName, service.getContactList().get(0).getLastName());
		assertThrows(IllegalArgumentException.class,
				() -> service.setLastName(service.getContactList().get(0).getContactID(), longLastName));
		assertThrows(IllegalArgumentException.class,
				() -> service.setLastName(service.getContactList().get(0).getContactID(), null));
		assertThrows(Exception.class, () -> service.setLastName(contactID, lastName));
	}

	@Test
	void updatePhoneNumberTest() throws Exception {
		ContactService service = new ContactService();
		service.newContact();
		service.setNumber(service.getContactList().get(0).getContactID(), number);

		assertEquals(number, service.getContactList().get(0).getNumber());
		assertThrows(IllegalArgumentException.class,
				() -> service.setNumber(service.getContactList().get(0).getContactID(), longNumber));
		assertThrows(IllegalArgumentException.class,
				() -> service.setNumber(service.getContactList().get(0).getContactID(), shortNumber));
		assertThrows(IllegalArgumentException.class,
				() -> service.setNumber(service.getContactList().get(0).getContactID(), "5551212"));
		assertThrows(IllegalArgumentException.class,
				() -> service.setNumber(service.getContactList().get(0).getContactID(), null));
		assertThrows(Exception.class, () -> service.setNumber(contactID, lastName));
	}

	@Test
	void updateAddressTest() throws Exception {
		ContactService service = new ContactService();
		service.newContact();
		service.setAddress(service.getContactList().get(0).getContactID(), address);
		assertEquals(address, service.getContactList().get(0).getAddress());
		assertThrows(IllegalArgumentException.class,
				() -> service.setAddress(service.getContactList().get(0).getContactID(), longAddress));
		assertThrows(IllegalArgumentException.class,
				() -> service.setAddress(service.getContactList().get(0).getContactID(), null));
		assertThrows(Exception.class, () -> service.setAddress(contactID, address));
	}

}