package Contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

class ContactTest  {

	protected String contactID, firstName, lastName, number, address;
	protected String longContactID, longFirstName, longLastName, longNumber, longAddress, shortNumber;
	
	@BeforeEach
	void setUp() {
		contactID = "659856985";
		firstName = "INITIAL";
		lastName = "INITIAL";
		number = "9876543210";
		address = "INITIAL";
		longContactID = "012345678901";
		longFirstName = "hdgfhrtdgfhdyehdgdtrhr";
		longLastName = "jfhdhdhyehennendhdhd";
		longNumber = "5264599856522";
		longAddress = "1600 really long address for test Av springfield";
		shortNumber = "2";		
	}
	
	
	@Test
	void contactConstructorTest() {
		Contact contact = new Contact();
		assertAll("No Arguments Contstructor",
			()-> assertNotNull(contact.getContactID()),
            ()-> assertNotNull(contact.getFirstName()),
            ()-> assertNotNull(contact.getLastName()),              
            ()-> assertNotNull(contact.getNumber()),
            ()-> assertNotNull(contact.getAddress()));   				
	}
	
	
	@Test
	void contactIDConstructorTest() {
		Contact contact = new Contact(contactID);
		assertAll("Contact ID Constructor Test",
				() -> assertEquals(contactID, contact.getContactID()),
				()-> assertNotNull(contact.getFirstName()),
	            ()-> assertNotNull(contact.getLastName()),              
	            ()-> assertNotNull(contact.getNumber()),
	            ()-> assertNotNull(contact.getAddress())); 
	}
	
	
	@Test 
	void firstNameConstructorTest() {
		Contact contact = new Contact(contactID, firstName);
		assertAll("firstNameConstructorTest",
				() -> assertEquals(contactID, contact.getContactID()),
				()-> assertEquals(firstName, contact.getFirstName()),
	            ()-> assertNotNull(contact.getLastName()),              
	            ()-> assertNotNull(contact.getNumber()),
	            ()-> assertNotNull(contact.getAddress())); 
	}
	
	
	@Test
	void lastNameConstructorTest() {
		Contact contact = new Contact(contactID, firstName, lastName);
		assertAll("lastNameConstructorTest",
				() -> assertEquals(contactID, contact.getContactID()),
				()-> assertEquals(firstName, contact.getFirstName()),
	            ()-> assertEquals(lastName, contact.getLastName()),              
	            ()-> assertNotNull(contact.getNumber()),
	            ()-> assertNotNull(contact.getAddress())); 
	}
	
	
	@Test
	void numberConstructorTest() {
		Contact contact = new Contact(contactID, firstName, lastName, number);
		assertAll("numberConstructorTest",
				() -> assertEquals(contactID, contact.getContactID()),
				()-> assertEquals(firstName, contact.getFirstName()),
	            ()-> assertEquals(lastName, contact.getLastName()),              
	            ()-> assertEquals(number, contact.getNumber()),
	            ()-> assertNotNull(contact.getAddress()));
	}
	
	//test creation of a contact with all fields provided
	@Test
	void addressConstructorTest() {
		Contact contact = new Contact(contactID,firstName, lastName, number, address  );
		assertAll("addressConstructorTest", 
				() -> assertEquals(contactID, contact.getContactID()),
				()-> assertEquals(firstName, contact.getFirstName()),
	            ()-> assertEquals(lastName, contact.getLastName()),              
	            ()-> assertEquals(number, contact.getNumber()),
	            ()-> assertEquals(address, contact.getAddress()));
	}
	
	
	@Test
	void setFirstNameTest() {
		Contact contact = new Contact();
		contact.setFirstName(firstName);
		assertAll("firstNameTest",
			()-> assertEquals(firstName, contact.getFirstName()),
	        ()-> assertThrows(IllegalArgumentException.class,() -> contact.setFirstName(null)),    
	        ()-> assertThrows(IllegalArgumentException.class,() -> contact.setFirstName(longFirstName)));				
	}
	
	
	@Test 
	void setLastNameTest() {
		Contact contact = new Contact();
		contact.setLastName(firstName);
		assertAll("lastNameTest",
			()-> assertEquals(lastName, contact.getFirstName()),
	        ()-> assertThrows(IllegalArgumentException.class,() -> contact.setLastName(null)),    
	        ()-> assertThrows(IllegalArgumentException.class,() -> contact.setLastName(longLastName)));
	}
	
	
	@Test
	void setNumberTest() {
		Contact contact = new Contact();
		contact.setNumber(number);
		assertAll("numberTest",
			()-> assertEquals(number, contact.getNumber()),
	        ()-> assertThrows(IllegalArgumentException.class,() -> contact.setNumber("")),    
	        ()-> assertThrows(IllegalArgumentException.class,() -> contact.setNumber(longNumber)),
	        ()-> assertThrows(IllegalArgumentException.class,() -> contact.setNumber(shortNumber)));
	}
	
	@Test
	void setAddressTest() {
		Contact contact = new Contact();
		contact.setAddress(address);
		assertAll("addressTest",
				()-> assertEquals(address, contact.getAddress()),
		        ()-> assertThrows(IllegalArgumentException.class,() -> contact.setAddress(null)),    
		        ()-> assertThrows(IllegalArgumentException.class,() -> contact.setAddress(longAddress)));
	}
	
	@Test
	void setContactIDTest() {
		Contact contact = new Contact();
		contact.setContactID(contactID);
		assertAll("contactIDTest",
				()-> assertEquals(contactID, contact.getContactID()),
		        ()-> assertThrows(IllegalArgumentException.class,() -> contact.setContactID(null)),    
		        ()-> assertThrows(IllegalArgumentException.class,() -> contact.setContactID(longContactID)));
	}
}